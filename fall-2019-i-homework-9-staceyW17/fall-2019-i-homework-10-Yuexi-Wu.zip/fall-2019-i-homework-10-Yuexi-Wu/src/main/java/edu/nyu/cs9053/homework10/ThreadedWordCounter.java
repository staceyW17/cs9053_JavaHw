package edu.nyu.cs9053.homework10;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

/**
 * User: blangel
 * Date: 11/16/14
 * Time: 3:16 PM
 */
public class ThreadedWordCounter extends AbstractThreadedCounter implements WordCounter {

    public ThreadedWordCounter(int concurrencyFactor) {
        super(concurrencyFactor);
    }

    @Override public void count(String fileContents, String word, Callback callback) {
        // TODO - implement this class using Thread objects; one Thread per {@link #concurrencyFactor}
        // HINT - break up {@linkplain fileContents} and distribute the work across the threads
        // HINT - do not create the Thread objects in this method

        final AtomicLong countResult = new AtomicLong(0l);
        String[] breakUps = fileContents.split(" ");
        CountDownLatch latch = new CountDownLatch(breakUps.length);
        for (String currentWord : breakUps) {
            getWork().offer(new Runnable() {
                @Override
                public void run() {
                    if (currentWord.equalsIgnoreCase(word)) {
                        countResult.incrementAndGet();
                    }
                    latch.countDown();
                }
            });
        }
        try {
            latch.await();
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(ie);
        }
        callback.counted(countResult.get());
    }

    @Override public void stop() {
        // TODO - stop the threads
        stopThreads();
    }

}
