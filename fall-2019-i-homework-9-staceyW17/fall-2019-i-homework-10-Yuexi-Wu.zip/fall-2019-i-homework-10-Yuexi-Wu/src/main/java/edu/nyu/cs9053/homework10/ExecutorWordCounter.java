package edu.nyu.cs9053.homework10;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

/**
 * User: blangel
 * Date: 11/16/14
 * Time: 3:33 PM
 */
public class ExecutorWordCounter extends AbstractConcurrencyFactorProvider implements WordCounter {

    private final ExecutorService executorService;


    public ExecutorWordCounter(int concurrencyFactor) {
        super(concurrencyFactor);
        this.executorService = Executors.newFixedThreadPool(concurrencyFactor);
    }

    @Override public void count(String fileContents, String word, Callback callback) {
        // TODO - implement this class using calls to an ExecutorService; one call per {@link #concurrencyFactor}
        // HINT - break up {@linkplain fileContents} and distribute the work across the calls
        // HINT - do not create the ExecutorService object in this method
        final AtomicLong count = new AtomicLong(0L);
        String[] words = fileContents.split(" ");
        final CountDownLatch latch = new CountDownLatch(words.length);
        for (final String current : words) {
            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    long currentCount = count.get();
                    if (current.equalsIgnoreCase(word)) {
                        count.set(currentCount++);
                    }
                    latch.countDown();
                }
            });
        }
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        callback.counted(count.get());
    }

    @Override public void stop() {
        // TODO - stop the executor
        executorService.shutdownNow();
    }
}
