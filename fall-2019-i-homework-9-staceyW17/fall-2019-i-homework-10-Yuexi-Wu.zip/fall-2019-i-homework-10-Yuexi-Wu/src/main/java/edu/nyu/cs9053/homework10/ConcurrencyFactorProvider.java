package edu.nyu.cs9053.homework10;

/**
 * User: blangel
 * Date: 11/16/14
 * Time: 3:48 PM
 */
interface ConcurrencyFactorProvider {

    int getConcurrencyFactor();

}
